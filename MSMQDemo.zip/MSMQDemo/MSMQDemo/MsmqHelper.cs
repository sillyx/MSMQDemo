﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Messaging;

namespace MSMQDemo
{
    public class MsmqHelper : IDisposable
    {
        private readonly string path;
        private MessageQueue mq;
        public MsmqHelper()
        {
            path = @".\private$\ZYQ2";  //这是本机实例的方式（专用队列）
            if (!MessageQueue.Exists(path))
                MessageQueue.Create(path);
            mq = new MessageQueue(path);
            mq.Formatter = new BinaryMessageFormatter();
            mq.Label = "description";//description  
        }
        //析构函数
        ~MsmqHelper()
        {
            mq.Dispose();
            //Dispose(false);
        }
        //发送消息
        public void SendMessage(object message)
        {
            mq.Send(new Message
            {
                Body = message,
                Formatter = new BinaryMessageFormatter(),
                Recoverable = true//在消息传递过程中将消息保存到磁盘上来保证消息的传递，默认为false。 
            });
        }
        //接收消息
        public object ReceiveMessage()
        {
            try
            {
                Message receivedMsg = new Message();
                receivedMsg.Formatter = new BinaryMessageFormatter();
                receivedMsg = mq.Receive();
                return receivedMsg == null ? null : receivedMsg.Body;
            }
            catch (Exception e)
            {
                //log
                return null;
            }
        }
        //释放
        public void Dispose()
        {
            //调用带参数的Dispose方法，释放托管和非托管资源
            Dispose(true);
            //手动调用了Dispose释放资源，那么析构函数就是不必要的了，这里阻止GC调用析构函数
            System.GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                //TODO:在这里加入清理"托管资源"的代码，应该是xxx.Dispose();
                mq.Dispose();
            }
            else
                //TODO:在这里加入清理"非托管资源"的代码 
                return;//GC.Collect();

        }
    }
}