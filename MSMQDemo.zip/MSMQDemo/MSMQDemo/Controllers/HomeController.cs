﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MSMQDemo.Controllers
{
    public class HomeController : Controller
    {
        private MsmqHelper mqHelper;
        private static string msg = string.Empty;
        public HomeController()
        {
            mqHelper = new MsmqHelper();
        }

        public ActionResult Index()
        {
            new System.Threading.Thread(() => { SendMess(); }).Start();
            while (true)
            {
                var msg1 = (Message)mqHelper.ReceiveMessage();
                msg = (msg1.Sender + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "偷偷发送了一则电报，已被截获：" + msg1.Content);
                Response.Write(msg + "<br />");
                if (Response.IsClientConnected)
                    Response.Flush();
            }
        }
        //发送消息进程
        public void SendMess()
        {
            while (true)
            {
                mqHelper.SendMessage(new Message { Content = Guid.NewGuid().ToString("N"), Sender = "张三虫" });
                System.Threading.Thread.Sleep(1000);
            }
        }

    }
    [Serializable]
    public class Message
    {
        public string Sender { get; set; }
        public string Content { get; set; }
    }
}
